# Raw Splitted > 2023-10-15 1:21am
https://universe.roboflow.com/airlangga-university-qy7ao/raw-splitted

Provided by a Roboflow user
License: CC BY 4.0

